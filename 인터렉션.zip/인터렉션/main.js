/* ============================================================
   낙타 자세 코스 — 1번 화면 → 2번 화면 자동 전환

   [1번 화면]  mp4 레퍼런스
     카드가 화면 밖 아래에서 강한 ease-out 으로 쑥 올라와 멎고,
     그 뒤에 알약 / 15분 뱃지 / 스와이프 힌트가 차례로 붙는다.
     이 단계에는 CTA 가 없다.

   [2번 화면]  mov 레퍼런스 (프로필 눌렀을 때 올라오는 그 느낌)
     여자 이미지 카드가 ease-out 으로 49px 위로 올라가고,
     6단계 카드가 아래에서 하나씩 스태거로 나타난 뒤
     CTA 가 마지막으로 올라온다.
   ============================================================ */

const screen   = document.getElementById('screen');
const scroller = document.getElementById('scroller');
const hint     = document.getElementById('hint');
const btnReplay = document.getElementById('btnReplay');
const phone    = document.getElementById('phone');

/* 각 구간이 시작되는 시각 (ms) */
const T = {
  lit:  240,    // 1번 화면 : 카드가 올라오기 시작
  open: 1950,   // 2번 화면 : 자동으로 넘어간다
};

let timers = [];
let opened = false;

function at(ms, fn) {
  timers.push(setTimeout(fn, ms));
}
function clearTimers() {
  timers.forEach(clearTimeout);
  timers = [];
}

/* ---------- 2번 화면으로 ---------- */
function open() {
  if (opened) return;
  opened = true;

  screen.classList.add('is-open');

  /* 카드와 6단계가 다 자리 잡은 뒤에 스크롤을 열어준다.
     (전환 중에 스크롤이 끼어들면 올라오는 맛이 깨진다) */
  at(1000, () => screen.classList.add('is-scrollable'));
}

/* ---------- 처음부터 다시 ---------- */
function play() {
  clearTimers();
  opened = false;

  /* 되감을 때는 트랜지션을 끄고 시작 상태로 딱 붙인다.
     안 그러면 카드가 아래로 한 번 흘렀다가 다시 올라온다. */
  screen.classList.add('no-anim');
  screen.classList.remove('is-lit', 'is-open', 'is-scrollable');
  scroller.scrollTop = 0;

  void screen.offsetWidth;          // 시작 상태를 강제로 반영
  screen.classList.remove('no-anim');
  void screen.offsetWidth;

  at(T.lit,  () => screen.classList.add('is-lit'));
  at(T.open, open);
}

/* ============================================================
   조작
   ============================================================ */

/* 힌트를 누르거나, 카드를 위로 스와이프하면 기다리지 않고 바로 넘어간다 */
hint.addEventListener('click', open);

let touchY = null;
screen.addEventListener('touchstart', (e) => {
  if (!opened) touchY = e.touches[0].clientY;
}, { passive: true });

screen.addEventListener('touchmove', (e) => {
  if (opened || touchY === null) return;
  if (touchY - e.touches[0].clientY > 24) { touchY = null; open(); }
}, { passive: true });

/* 데스크톱에서는 휠을 위로 굴리면 같은 동작 */
screen.addEventListener('wheel', (e) => {
  if (!opened && e.deltaY > 8) open();
}, { passive: true });

btnReplay.addEventListener('click', play);

/* ============================================================
   창 크기에 맞춰 폰을 통째로 스케일
   ============================================================ */
function fit() {
  const pad = 96;   // 위아래 여백 + 조작 패널
  const s = Math.min(1, (window.innerHeight - pad) / 812);
  phone.style.setProperty('--scale', s);
  /* 스케일 뒤 실제로 차지하는 높이만큼만 자리를 잡도록 */
  phone.style.height = (812 * s) + 'px';
  phone.style.width  = (375 * s) + 'px';
  phone.style.transformOrigin = 'top left';
}
window.addEventListener('resize', fit);
fit();

play();
